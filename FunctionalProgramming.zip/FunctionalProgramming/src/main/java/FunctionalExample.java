/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class FunctionalExample {
    public static void main(String[] args) {
int number = 5;
// Using a built-in function instead of manual computation
int square = Math.multiplyExact(number, number);
System.out.println("Square of " + number + " is: " + square);
}
}
