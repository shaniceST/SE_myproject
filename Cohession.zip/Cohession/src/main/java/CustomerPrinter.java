/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class CustomerPrinter {
    //This class only handles printing - single responsibility
    public void printCustomer(Customer customer) {
        System.out.println(customer.getCustomerInfo());
    }
}

